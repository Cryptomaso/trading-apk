import { View, StyleSheet } from 'react-native';
import TradingForm from '@/components/TradingForm';
import { useTradingContext } from '@/context/TradingContext';

export default function HomeScreen() {
  const { addTrade } = useTradingContext();

  return (
    <View style={styles.container}>
      <TradingForm onSubmit={addTrade} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F1F5F9',
  },
});