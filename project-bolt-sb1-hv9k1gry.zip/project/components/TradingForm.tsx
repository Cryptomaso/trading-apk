import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Platform,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { ChevronDown, Plus } from 'lucide-react-native';
import { Trading } from '@/types/trading';

interface TradingFormProps {
  onSubmit: (trade: Omit<Trading, 'id'>) => Promise<void>;
}

const CURRENCIES = ['CUP', 'USD', 'EUR', 'HIVE', 'BTC', 'ETH'];

export default function TradingForm({ onSubmit }: TradingFormProps) {
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [operation, setOperation] = useState<'Compra' | 'Venta'>('Compra');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('HIVE');
  const [price, setPrice] = useState('');
  const [tradingCurrency, setTradingCurrency] = useState('CUP');
  const [showCurrencyPicker, setShowCurrencyPicker] = useState(false);
  const [showTradingCurrencyPicker, setShowTradingCurrencyPicker] = useState(false);

  const handleDateChange = (event: any, selectedDate?: Date) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setDate(selectedDate);
    }
  };

  const handleSubmit = async () => {
    if (!amount || !price) {
      return;
    }

    const trade = {
      date,
      operation,
      amount,
      currency,
      price,
      tradingCurrency,
    };

    await onSubmit(trade);
    
    // Reset form
    setAmount('');
    setPrice('');
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
    });
  };

  return (
    <View style={styles.container}>
      {/* Date Field */}
      <View style={styles.field}>
        <Text style={styles.label}>Fecha</Text>
        <TouchableOpacity
          style={styles.dateInput}
          onPress={() => setShowDatePicker(true)}>
          <Text style={styles.dateText}>{formatDate(date)}</Text>
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={date}
            mode="date"
            display="default"
            onChange={handleDateChange}
          />
        )}
      </View>

      {/* Operation Type */}
      <View style={styles.field}>
        <Text style={styles.label}>Operación</Text>
        <View style={styles.operationContainer}>
          <TouchableOpacity
            style={[
              styles.operationButton,
              operation === 'Compra' && styles.operationButtonActive,
            ]}
            onPress={() => setOperation('Compra')}>
            <Text
              style={[
                styles.operationButtonText,
                operation === 'Compra' && styles.operationButtonTextActive,
              ]}>
              Compra
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.operationButton,
              operation === 'Venta' && styles.operationButtonActive,
            ]}
            onPress={() => setOperation('Venta')}>
            <Text
              style={[
                styles.operationButtonText,
                operation === 'Venta' && styles.operationButtonTextActive,
              ]}>
              Venta
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Amount and Currency */}
      <View style={styles.field}>
        <Text style={styles.label}>Cantidad</Text>
        <View style={styles.row}>
          <TextInput
            style={[styles.input, styles.flex1]}
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
            placeholder="0.00"
          />
          <TouchableOpacity
            style={styles.currencyButton}
            onPress={() => setShowCurrencyPicker(!showCurrencyPicker)}>
            <Text style={styles.currencyButtonText}>{currency}</Text>
            <ChevronDown size={20} color="#64748B" />
          </TouchableOpacity>
        </View>
        {showCurrencyPicker && (
          <View style={styles.currencyPicker}>
            {CURRENCIES.map((curr) => (
              <TouchableOpacity
                key={curr}
                style={styles.currencyOption}
                onPress={() => {
                  setCurrency(curr);
                  setShowCurrencyPicker(false);
                }}>
                <Text
                  style={[
                    styles.currencyOptionText,
                    curr === currency && styles.currencyOptionTextSelected,
                  ]}>
                  {curr}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      {/* Price and Trading Currency */}
      <View style={styles.field}>
        <Text style={styles.label}>Precio</Text>
        <View style={styles.row}>
          <View style={[styles.priceContainer, styles.flex1]}>
            <TouchableOpacity style={styles.priceButton}>
              <Plus size={20} color="#3B82F6" />
            </TouchableOpacity>
            <TextInput
              style={styles.priceInput}
              value={price}
              onChangeText={setPrice}
              keyboardType="decimal-pad"
              placeholder="0.00"
            />
          </View>
          <TouchableOpacity
            style={styles.currencyButton}
            onPress={() => setShowTradingCurrencyPicker(!showTradingCurrencyPicker)}>
            <Text style={styles.currencyButtonText}>{tradingCurrency}</Text>
            <ChevronDown size={20} color="#64748B" />
          </TouchableOpacity>
        </View>
        {showTradingCurrencyPicker && (
          <View style={styles.currencyPicker}>
            {CURRENCIES.map((curr) => (
              <TouchableOpacity
                key={curr}
                style={styles.currencyOption}
                onPress={() => {
                  setTradingCurrency(curr);
                  setShowTradingCurrencyPicker(false);
                }}>
                <Text
                  style={[
                    styles.currencyOptionText,
                    curr === tradingCurrency && styles.currencyOptionTextSelected,
                  ]}>
                  {curr}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      {/* Submit Button */}
      <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
        <Text style={styles.submitButtonText}>Guardar Operación</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    gap: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  field: {
    gap: 8,
  },
  label: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#1E293B',
  },
  dateInput: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#F8FAFC',
  },
  dateText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1E293B',
  },
  operationContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  operationButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
  },
  operationButtonActive: {
    backgroundColor: '#3B82F6',
  },
  operationButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#64748B',
  },
  operationButtonTextActive: {
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  flex1: {
    flex: 1,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#F8FAFC',
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1E293B',
  },
  currencyButton: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#F8FAFC',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    minWidth: 100,
  },
  currencyButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#1E293B',
  },
  currencyPicker: {
    position: 'absolute',
    top: '100%',
    right: 0,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    zIndex: 1000,
  },
  currencyOption: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  currencyOptionText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1E293B',
  },
  currencyOptionTextSelected: {
    color: '#3B82F6',
    fontFamily: 'Inter-SemiBold',
  },
  priceContainer: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    backgroundColor: '#F8FAFC',
    flexDirection: 'row',
    alignItems: 'center',
  },
  priceButton: {
    padding: 12,
    borderRightWidth: 1,
    borderRightColor: '#E2E8F0',
  },
  priceInput: {
    flex: 1,
    padding: 12,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1E293B',
  },
  submitButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
  },
  submitButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#fff',
  },
});