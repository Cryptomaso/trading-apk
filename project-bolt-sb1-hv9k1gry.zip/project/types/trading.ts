export interface Trading {
  id: string;
  date: Date;
  operation: 'Compra' | 'Venta';
  amount: string;
  currency: string;
  price: string;
  tradingCurrency: string;
}

export interface TradingContextType {
  trades: Trading[];
  addTrade: (trade: Omit<Trading, 'id'>) => Promise<void>;
  removeTrade: (id: string) => Promise<void>;
  loadTrades: () => Promise<void>;
}