import { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Trading, TradingContextType } from '@/types/trading';

const TradingContext = createContext<TradingContextType | undefined>(undefined);

export function TradingProvider({ children }: { children: React.ReactNode }) {
  const [trades, setTrades] = useState<Trading[]>([]);

  useEffect(() => {
    loadTrades();
  }, []);

  const loadTrades = async () => {
    try {
      const storedTrades = await AsyncStorage.getItem('trades');
      if (storedTrades) {
        setTrades(JSON.parse(storedTrades));
      }
    } catch (error) {
      console.error('Error loading trades:', error);
    }
  };

  const addTrade = async (trade: Omit<Trading, 'id'>) => {
    try {
      const newTrade = {
        ...trade,
        id: Date.now().toString(),
      };
      const updatedTrades = [...trades, newTrade];
      await AsyncStorage.setItem('trades', JSON.stringify(updatedTrades));
      setTrades(updatedTrades);
    } catch (error) {
      console.error('Error adding trade:', error);
    }
  };

  const removeTrade = async (id: string) => {
    try {
      const updatedTrades = trades.filter(trade => trade.id !== id);
      await AsyncStorage.setItem('trades', JSON.stringify(updatedTrades));
      setTrades(updatedTrades);
    } catch (error) {
      console.error('Error removing trade:', error);
    }
  };

  return (
    <TradingContext.Provider value={{ trades, addTrade, removeTrade, loadTrades }}>
      {children}
    </TradingContext.Provider>
  );
}

export function useTradingContext() {
  const context = useContext(TradingContext);
  if (context === undefined) {
    throw new Error('useTradingContext must be used within a TradingProvider');
  }
  return context;
}